package com.aiteam

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Одна подключённая нейросеть. type: "openai" (совместимый адрес) или "anthropic". */
class Provider(
    val id: String,
    val name: String,
    val type: String,
    val url: String,
    val model: String,
    val key: String
)

class Preset(val name: String, val type: String, val url: String, val model: String, val note: String)

object Presets {
    val all: List<Preset> = listOf(
        Preset("Gemini", "openai", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "gemini-3.8-flash", "Бесплатно. Ключ: aistudio.google.com/apikey"),
        Preset("Groq", "openai", "https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile", "Бесплатно. Ключ: console.groq.com"),
        Preset("OpenRouter", "openai", "https://openrouter.ai/api/v1/chat/completions", "openrouter/free", "Бесплатные модели. Ключ: openrouter.ai"),
        Preset("Mistral", "openai", "https://api.mistral.ai/v1/chat/completions", "mistral-small-latest", "Бесплатный тариф. Ключ: console.mistral.ai"),
        Preset("Cerebras", "openai", "https://api.cerebras.ai/v1/chat/completions", "llama-3.3-70b", "Бесплатный тариф. Ключ: cloud.cerebras.ai"),
        Preset("DeepSeek", "openai", "https://api.deepseek.com/chat/completions", "deepseek-chat", "Платно, дёшево. Ключ: platform.deepseek.com"),
        Preset("GPT", "openai", "https://api.openai.com/v1/chat/completions", "gpt-4o-mini", "Платно. Ключ: platform.openai.com"),
        Preset("Claude", "anthropic", "https://api.anthropic.com/v1/messages", "claude-haiku-5-5", "Платно. Ключ: console.anthropic.com"),
        Preset("Свой", "openai", "", "", "Любой OpenAI-совместимый адрес")
    )
}

object Store {
    private var prefs: SharedPreferences? = null
    private val items = ArrayList<Provider>()
    @Volatile private var leaderKey: String = ""

    @Synchronized
    fun init(c: Context) {
        if (prefs != null) return
        val p = c.applicationContext.getSharedPreferences("team", Context.MODE_PRIVATE)
        prefs = p
        items.clear()
        try {
            val a = JSONArray(p.getString("providers", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                items.add(
                    Provider(
                        o.getString("id"), o.getString("name"), o.getString("type"),
                        o.getString("url"), o.getString("model"), o.getString("key")
                    )
                )
            }
        } catch (e: Exception) {
            items.clear()
        }
        leaderKey = p.getString("leader", "") ?: ""
    }

    @Synchronized
    private fun save() {
        val a = JSONArray()
        for (p in items) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            o.put("type", p.type)
            o.put("url", p.url)
            o.put("model", p.model)
            o.put("key", p.key)
            a.put(o)
        }
        prefs?.edit()?.putString("providers", a.toString())?.putString("leader", leaderKey)?.apply()
    }

    @Synchronized
    fun list(): List<Provider> = ArrayList<Provider>(items)

    @Synchronized
    fun add(p: Provider) {
        items.add(p)
        save()
    }

    @Synchronized
    fun remove(id: String) {
        val it = items.iterator()
        while (it.hasNext()) {
            if (it.next().id == id) it.remove()
        }
        if (leaderKey == id) leaderKey = ""
        save()
    }

    @Synchronized
    fun chooseLeader(id: String) {
        leaderKey = id
        save()
    }

    @Synchronized
    fun leader(): Provider? {
        for (p in items) if (p.id == leaderKey) return p
        return null
    }
}

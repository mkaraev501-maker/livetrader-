package com.aiteam

import android.os.Handler
import android.os.Looper

/** Общий чат команды и сценарии работы: обсуждение, выбор главного, задача с кодом, улучшение. */
object Team {
    private class Msg(val who: String, val text: String)
    private class Roles(val leader: Provider, val coder: Provider, val reviewers: List<Provider>)

    private val msgs = ArrayList<Msg>()
    private val dead = HashSet<String>()   // нейросети, исключённые до конца работы (неверный ключ, нет денег)
    private val log = StringBuilder()
    private val main = Handler(Looper.getMainLooper())
    private val fence = Regex("```(?:html|HTML)?\\s*\\n([\\s\\S]*?)```")

    @Volatile var stop: Boolean = false
    @Volatile var running: Boolean = false
    @Volatile var html: String = ""
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile private var lastTask: String = ""

    fun transcript(): String = synchronized(log) { log.toString() }

    private fun ping() {
        val cb = onChange ?: return
        main.post { cb() }
    }

    fun add(who: String, text: String) {
        synchronized(log) {
            msgs.add(Msg(who, text))
            log.append("\n\n").append(who).append(": ").append(text)
            if (log.length > 60000) log.delete(0, log.length - 40000)
        }
        ping()
    }

    /** Служебная строка: видна пользователю, но нейросетям в контекст не попадает. */
    fun note(text: String) {
        synchronized(log) { log.append("\n").append(text) }
        ping()
    }

    private fun context(maxChars: Int): String {
        val parts = ArrayList<String>()
        synchronized(log) {
            var total = 0
            var i = msgs.size - 1
            while (i >= 0) {
                val m = msgs[i]
                val line = m.who + ": " + m.text
                if (total + line.length > maxChars && parts.isNotEmpty()) break
                parts.add(line)
                total += line.length
                i--
            }
        }
        parts.reverse()
        val sb = StringBuilder()
        for (p in parts) sb.append(p).append("\n\n")
        return sb.toString()
    }

    private fun names(ps: List<Provider>): String = ps.joinToString(", ") { it.name }

    private fun sys(p: Provider, ps: List<Provider>): String =
        "Ты " + p.name + ", участник команды нейросетей. Участники: " + names(ps) +
            ". Отвечай по-русски, по делу, без воды. Не упоминай, что ты ИИ-модель другой компании."

    private fun pause() = Net.sleepStoppable(2500)

    private fun launchJob(block: () -> Unit) {
        if (running) return
        running = true
        stop = false
        dead.clear()
        ping()
        val t = Thread {
            try {
                block()
            } catch (e: Exception) {
                if (stop) note("Остановлено.") else note("Ошибка: " + (e.message ?: e.toString()))
            } finally {
                running = false
                ping()
            }
        }
        t.isDaemon = true
        t.start()
    }

    /** Спросить с защитой: если одна нейросеть не ответила, остальные продолжают. */
    private fun tryAsk(p: Provider, ps: List<Provider>, prompt: String): String? {
        if (dead.contains(p.id)) return null
        return try {
            Net.ask(p, sys(p, ps), prompt)
        } catch (e: Exception) {
            if (!stop) {
                val msg = (e.message ?: e.toString()).take(160)
                if (e is Net.HttpError && e.code in 400..404) {
                    dead.add(p.id)
                    note("  " + p.name + " исключена до конца работы: " + msg)
                } else {
                    note("  " + p.name + " не ответила: " + msg)
                }
            }
            null
        }
    }

    private fun roles(ps: List<Provider>): Roles {
        val leader = Store.leader() ?: ps[0]
        val others = ps.filter { it.id != leader.id }
        val coder = if (others.isNotEmpty()) others[0] else leader
        val reviewers = if (others.size > 1) others.drop(1).take(2) else listOf(leader)
        return Roles(leader, coder, reviewers)
    }

    // ---------- обычный вопрос всей команде ----------

    fun discuss(question: String) {
        launchJob {
            val ps = Store.list()
            if (ps.isEmpty()) {
                add("Система", "Сначала добавь нейросети во вкладке «Нейросети».")
                return@launchJob
            }
            add("Ты", question)
            for (p in ps) {
                if (stop) break
                val r = tryAsk(
                    p, ps,
                    "Обсуждение команды:\n" + context(7000) +
                        "\nОтветь на последний вопрос пользователя коротко (3-6 предложений), учитывая ответы коллег."
                )
                if (r != null) add(p.name, r)
                pause()
            }
        }
    }

    // ---------- выбор главного ----------

    private fun pick(reply: String, cands: List<Provider>): Provider? {
        val low = reply.lowercase()
        var best: Provider? = null
        var bestIdx = Int.MAX_VALUE
        for (c in cands) {
            val i = low.indexOf(c.name.lowercase())
            if (i >= 0 && i < bestIdx) {
                best = c
                bestIdx = i
            }
        }
        return best
    }

    fun election(minutes: Int) {
        launchJob {
            val ps = Store.list()
            if (ps.size < 2) {
                add("Система", "Для выбора главного нужно минимум две нейросети.")
                return@launchJob
            }
            val mins = minutes.coerceIn(1, 600)
            val deadline = System.currentTimeMillis() + mins * 60000L
            add("Система", "Выбираем главного. Спорят до " + mins + " мин (максимум 3 круга), потом голосование.")
            var round = 0
            while (round < 3 && System.currentTimeMillis() < deadline && !stop) {
                for (p in ps) {
                    if (stop || System.currentTimeMillis() >= deadline) break
                    val r = tryAsk(
                        p, ps,
                        "Идёт спор, кто из вас будет главным в команде.\n" + context(7000) +
                            "\nТвоя реплика (2-4 предложения): аргументируй, кто лучше всего подходит на роль главного " +
                            "(можно себя или другого), и ответь на доводы коллег."
                    )
                    if (r != null) add(p.name, r)
                    pause()
                }
                round++
            }
            if (stop) {
                note("Выбор остановлен.")
                return@launchJob
            }
            val live = ps.filter { !dead.contains(it.id) }
            if (live.isEmpty()) {
                add("Система", "Ни одна нейросеть не ответила. Проверь ключи и баланс во вкладке «Нейросети».")
                return@launchJob
            }
            var cands: List<Provider> = live
            var winner: Provider? = null
            for (turn in 0 until 2) {
                val votes = HashMap<String, Int>()
                for (c in cands) votes[c.id] = 0
                for (v in live) {
                    if (stop) break
                    val r = tryAsk(
                        v, ps,
                        "Голосование за главного. Варианты: " + names(cands) + ".\nОбсуждение:\n" + context(5000) +
                            "\nОтветь ТОЛЬКО одним именем из списка вариантов, ничего больше."
                    )
                    val c = if (r == null) null else pick(r, cands)
                    if (c != null) {
                        votes[c.id] = (votes[c.id] ?: 0) + 1
                        note("  " + v.name + " голосует за " + c.name)
                    } else {
                        note("  " + v.name + " воздержалась")
                    }
                    pause()
                }
                if (stop) {
                    note("Выбор остановлен.")
                    return@launchJob
                }
                var max = 0
                for (c in cands) max = Math.max(max, votes[c.id] ?: 0)
                val tied = cands.filter { (votes[it.id] ?: 0) == max }
                if (tied.size == 1) {
                    winner = tied[0]
                    break
                }
                if (turn == 0) {
                    note("Ничья между: " + names(tied) + ". Переголосовываем только между ними.")
                    cands = tied
                } else {
                    winner = tied[0]
                    note("Снова ничья, главным назначен первый из них по списку.")
                }
            }
            val w = winner
            if (w != null) {
                Store.chooseLeader(w.id)
                add("Система", "Главный: " + w.name + ". Он распределяет роли в задачах.")
            }
        }
    }

    // ---------- задача командой с кодом ----------

    fun extractHtml(text: String): String {
        val m = fence.find(text)
        if (m != null) {
            val c = m.groupValues[1].trim()
            if (c.contains("<")) return c
        }
        val k = text.indexOf("```html")
        if (k >= 0) {
            val rest = text.substring(k + 7).trim().removeSuffix("```").trim()
            if (rest.contains("<")) return rest
        }
        var i = text.indexOf("<!DOCTYPE", 0, true)
        if (i < 0) i = text.indexOf("<html", 0, true)
        val j = text.lastIndexOf("</html>", text.length, true)
        if (i >= 0 && j > i) return text.substring(i, j + 7)
        return ""
    }

    private fun writeCode(p: Provider, ps: List<Provider>, prompt: String): Boolean {
        val r = tryAsk(p, ps, prompt) ?: return false
        val code = extractHtml(r)
        if (code.isEmpty()) {
            add(p.name + " (код)", "Ответил, но код не распознан. Начало ответа: " + r.take(200))
            return false
        }
        html = code
        add(p.name + " (код)", "Написал страницу (" + code.length + " символов). Смотри вкладку «Предпросмотр».")
        return true
    }

    private fun reviewAndFix(task: String, userNote: String, r: Roles, ps: List<Provider>) {
        if (stop) return
        val remarks = StringBuilder()
        for (rv in r.reviewers) {
            if (stop) return
            val a = tryAsk(
                rv, ps,
                "Задача: " + task + "\n" + userNote + "\nКод страницы:\n" + html.take(14000) +
                    "\n\nДай 3-5 конкретных улучшений: внешний вид, удобство на телефоне, ошибки. Коротко, не переписывай весь код."
            )
            if (a != null) {
                add(rv.name + " (проверка)", a)
                remarks.append(rv.name).append(": ").append(a).append("\n\n")
            }
            pause()
        }
        if (stop) return
        writeCode(
            r.coder, ps,
            "Задача: " + task + "\n" + userNote + "\n\nТекущий код:\n" + html.take(14000) +
                "\n\nЗамечания коллег:\n" + remarks +
                "\nУлучши код с учётом замечаний. Верни ПОЛНЫЙ обновлённый код одним блоком ```html без объяснений."
        )
    }

    private fun finish(task: String, leader: Provider, ps: List<Provider>) {
        if (stop) return
        val s = tryAsk(
            leader, ps,
            "Подведи итог в 2-3 предложениях: что сделала команда по задаче «" + task + "» и что ещё можно улучшить."
        )
        if (s != null) add(leader.name + " (итог)", s)
        add("Система", "Готово. Посмотри вкладку «Предпросмотр». Не нравится? Напиши, что улучшить, и нажми «Улучшить».")
    }

    fun build(task: String) {
        launchJob {
            val ps = Store.list()
            if (ps.isEmpty()) {
                add("Система", "Сначала добавь нейросети во вкладке «Нейросети».")
                return@launchJob
            }
            val r = roles(ps)
            lastTask = task
            add("Ты", "Задача: " + task)
            add("Система", "Главный: " + r.leader.name + ". Пишет код: " + r.coder.name + ". Проверяют: " + names(r.reviewers) + ".")
            val plan = tryAsk(
                r.leader, ps,
                "Ты главный в команде. Задача пользователя: " + task +
                    "\nСоставь короткий план (4-6 пунктов) для одной HTML-страницы (HTML, CSS и JS в одном файле): " +
                    "что будет на экране и как это работает на телефоне."
            ) ?: return@launchJob
            add(r.leader.name + " (главный)", plan)
            pause()
            if (stop) return@launchJob
            val ok = writeCode(
                r.coder, ps,
                "Задача: " + task + "\n\nПлан главного:\n" + plan +
                    "\n\nНапиши ПОЛНЫЙ код страницы одним файлом (HTML+CSS+JS), красивой и удобной на телефоне. " +
                    "Выдай только код одним блоком ```html без объяснений."
            )
            if (!ok) return@launchJob
            reviewAndFix(task, "", r, ps)
            finish(task, r.leader, ps)
        }
    }

    fun improve(feedback: String) {
        launchJob {
            val ps = Store.list()
            if (ps.isEmpty() || html.isEmpty()) {
                add("Система", "Сначала нужен код: напиши задачу и нажми «Задача командой».")
                return@launchJob
            }
            val r = roles(ps)
            val noteText = if (feedback.isBlank()) "Пользователь просит: сделайте ещё лучше."
            else "Пожелание пользователя: " + feedback
            add("Ты", noteText)
            reviewAndFix(if (lastTask.isEmpty()) "улучшение страницы" else lastTask, noteText, r, ps)
            finish(if (lastTask.isEmpty()) "улучшение страницы" else lastTask, r.leader, ps)
        }
    }
}
